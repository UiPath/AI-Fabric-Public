REPLICATED_ENVIRON="aif-core"

AVAILABLE_IMAGES=(
  "registry.replicated.com/${REPLICATED_ENVIRON}/uipath-uipath-core-s2i-python36:0.4-AIF"
  "registry.replicated.com/${REPLICATED_ENVIRON}/uipath-uipath-core-s2i-python37:0.4-AIF"
  "registry.replicated.com/${REPLICATED_ENVIRON}/uipath-uipath-core-s2i-python3-tf-gpu:0.4-AIF"
  "registry.replicated.com/${REPLICATED_ENVIRON}/uipath-uipath-core-s2i-python38:0.2-AIF"
  "registry.replicated.com/${REPLICATED_ENVIRON}/uipath-uipath-core-s2i-python38-tf-gpu:0.2-AIF"
  "registry.replicated.com/${REPLICATED_ENVIRON}/uipath-uipath-core-s2i-python3-cv-gpu:0.2-AIF"
  "registry.replicated.com/${REPLICATED_ENVIRON}/uipath-uipath-core-s2i-python27:0.1-AIF"
  "registry.replicated.com/${REPLICATED_ENVIRON}/uipathmlcontainerregistry.azurecr.io/aifabric_base_image:0.3-AIF"
  "registry.replicated.com/${REPLICATED_ENVIRON}/uipathmlcontainerregistry.azurecr.io-aifabric_base_image:20.11.0-AIF"
)

formulate_docker_command() {
    docker images registry
        if [[ $? -ne 0 ]]; then
                echo "sudo permission required for docker"
                DOCKER_COMMAND="sudo docker"
        else
                DOCKER_COMMAND="docker"
        fi
}

verify_kubectl_context() {
    kubectl get namespaces aifabric
    if [[ $? -ne 0 ]];
    then
            echo "Not able to connect to kubernetes. Please run 'bash -l' before running the script and retry"
            exit 1
    fi
}

set_image_prefix() {
    PATTERN_IMAGE=$($DOCKER_COMMAND images | grep "/ai-pkgmanager" | grep $REGISTRY_HOST | awk '{print $1}' | head -n 1)
    IMAGE_PREFIX=$(echo ${PATTERN_IMAGE}|sed -r "s|/ai-pkgmanager$||g")
    echo "Setting IMAGE_PREFIX to ${IMAGE_PREFIX}"
}

main() {
    formulate_docker_command
    verify_kubectl_context

    echo "Start docker login to local docker registry"

    REGISTRY_CONFIG=$(kubectl -n aifabric get configmap registry-config -o yaml)
    # get registry host
    REGISTRY_HOST_ARR=($(echo "${REGISTRY_CONFIG}"| grep REGISTRY_HOST|tr ":" " "))
    REGISTRY_HOST=${REGISTRY_HOST_ARR[1]}
    # get registry username
    REGISTRY_USERNAME_ARR=($(echo "${REGISTRY_CONFIG}"| grep REGISTRY_USERNAME|tr ":" " "))
    REGISTRY_USERNAME=${REGISTRY_USERNAME_ARR[1]}
    # get registry password
    REGISTRY_PASSWORD_ARR=($(echo "${REGISTRY_CONFIG}"| grep REGISTRY_PASSWORD|tr ":" " "))
    REGISTRY_PASSWORD=${REGISTRY_PASSWORD_ARR[1]}
    IS_DOCKER_LOGIN_SUCCESSFUL=$(${DOCKER_COMMAND} login ${REGISTRY_HOST} -u ${REGISTRY_USERNAME} -p ${REGISTRY_PASSWORD})
    if [ "Login Succeeded" != "${IS_DOCKER_LOGIN_SUCCESSFUL}" ]; then
        echo "Login failed using registry config, please check registry config and retry"
        exit 1
    else
        echo ${IS_DOCKER_LOGIN_SUCCESSFUL}
    fi

    set_image_prefix

    ERROR_RESPONSE="Response:Error"
    
    echo "Update Base Images with pytest-runner library"
    
    for IMAGE_NAME in "${AVAILABLE_IMAGES[@]}"; do
        LOCAL_IMAGE_NAME=$(echo ${IMAGE_NAME}|sed -r "s|registry.replicated.com/${REPLICATED_ENVIRON}|${IMAGE_PREFIX}|g")
        echo "Local image name is $LOCAL_IMAGE_NAME"

	echo "Pull base image ${LOCAL_IMAGE_NAME}"
	PULL_IMAGE_RESPONSE=$(${DOCKER_COMMAND} pull ${LOCAL_IMAGE_NAME} 2>&1)
        if [[ ${PULL_IMAGE_RESPONSE} == *"manifest for ${LOCAL_IMAGE_NAME} not found"* ]]; then
	    echo -e "Image ${LOCAL_IMAGE_NAME} not available in local registry \n\n"
	    continue
	fi

    	echo "Update with pytest-runner library"
        cp Dockerfile DockerfileRun
        sed -i "s|{BASE_IMAGE}|${LOCAL_IMAGE_NAME}|g" DockerfileRun

	echo "Build image ${LOCAL_IMAGE_NAME}"
	${DOCKER_COMMAND} build -f ./DockerfileRun -t ${LOCAL_IMAGE_NAME} .

	echo "Push updated image to registry"
	PUSH_IMAGE_RESPONSE=$(${DOCKER_COMMAND} push ${LOCAL_IMAGE_NAME})
        if [[ "${PUSH_IMAGE_RESPONSE}" == *${ERROR_RESPONSE}* ]]; then
            echo "${PUSH_IMAGE_RESPONSE}"
            echo "Failed to push image: ${file}"
        fi

	# cleanup resources
	rm -rf DockerfileRun
	${DOCKER_COMMAND} rmi -f ${LOCAL_IMAGE_NAME}
	echo "Updated Base Image Successfully ${LOCAL_IMAGE_NAME}"
    done
}

main
